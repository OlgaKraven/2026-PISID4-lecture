import type { Course, TeacherPack } from './model';
import type { Key } from './scoring';
export declare function validAsset(v: unknown, p: string): void;
export declare function validateStructure(value: unknown): asserts value is Course;
export declare function validateBank(value: unknown, course: Course): asserts value is {
    courseId: string;
    contentVersion: string;
    keys: Record<string, Key>;
};
export declare function validateTeacherPack(value: unknown, course: Course, allowOld?: boolean): asserts value is TeacherPack;
export declare function courseAssets(c: Course): string[];
export declare function readiness(c: Course): string[];
