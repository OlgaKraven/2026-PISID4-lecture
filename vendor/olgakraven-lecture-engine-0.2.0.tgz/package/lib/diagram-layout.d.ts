import type { ReactNode } from 'react';
import type { Visual } from './model';
export declare const diagramColors: string[];
export declare function wrapText(text: string, width: number, size?: number): string[];
export declare function DiagramText({ text, x, y, width, size, bold, color, center, }: {
    text: string;
    x: number;
    y: number;
    width: number;
    size?: number;
    bold?: boolean;
    color?: string;
    center?: boolean;
}): import("react").JSX.Element;
export declare function diagramLayout(v: Visual, marker: string, base: string): {
    height: number;
    content: ReactNode;
};
