import type { Course, Lecture, Profile } from './model';
type Props = {
    course: Course;
    lecture: Lecture;
    base: string;
    profile: Profile;
    mode: 'presenter' | 'audience';
    session: string;
    initialSlide: string;
    onExit: () => void;
};
export default function Teaching(props: Props): import("react").JSX.Element;
export {};
