import type { Visual } from './model';
export type DiagramView = 'diagram' | 'text' | null;
export declare const DiagramControl: import("react").Context<{
    view: DiagramView;
    setView: (view: DiagramView) => void;
} | null>;
export declare function Infographic({ visual, base }: {
    visual: Visual;
    base?: string;
}): import("react").JSX.Element;
