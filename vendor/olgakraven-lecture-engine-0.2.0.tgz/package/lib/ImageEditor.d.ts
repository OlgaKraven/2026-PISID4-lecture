import type { Slide } from './model';
export declare function ImageEditor({ image, onChange, }: {
    image: Slide['image'];
    onChange: (image: Slide['image']) => void;
}): import("react").JSX.Element;
