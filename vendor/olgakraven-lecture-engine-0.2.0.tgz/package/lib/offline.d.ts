export declare function offlineWorker(base: string): Promise<ServiceWorker>;
export declare function offlineCommand(base: string, type: 'PREPARE' | 'STATUS' | 'REMOVE'): Promise<{
    ready: boolean;
    count: number;
}>;
