import type { Lecture, Note } from './model';
export declare function TimingPlan({ lecture, notes, index, elapsed, sessionKey, onPause, }: {
    lecture: Lecture;
    notes: Record<string, Note>;
    index: number;
    elapsed: number;
    sessionKey: string;
    onPause: () => void;
}): import("react").JSX.Element;
